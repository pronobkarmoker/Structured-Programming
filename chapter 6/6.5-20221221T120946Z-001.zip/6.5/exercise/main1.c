#include<stdio.h>
#include<string.h>

int main()
{
    char *p[3]= {"Yes", "No", "Maybe. Rephrase the question"};
    char str[80];
    gets(str);
    int i= strlen(str)%3;
    printf("%s", p[i]);
    
    return 0;
}
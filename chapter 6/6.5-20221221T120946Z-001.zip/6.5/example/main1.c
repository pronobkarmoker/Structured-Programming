#include<stdio.h>

    char *p[]= {
        "Input exceeds field width",
        "Out of range",
        "Printer not turned on",
        "Paper out",
        "Disk full",
        "Disk write error"
    };
void error(int err_num)
{
    printf(p[err_num]);
}
int main()
{
    int n;
    scanf("%d", &n);
    error(n);
    return 0;
}
#include<stdio.h>

void main()
{
    int *ip, i;
    char *cp, ch;
    double *dp, d;
    float *fp, f;

    ip = &i;
    cp = &ch;
    dp = &d;
    fp = &f;

    printf("%p %p %p %p\n", ip, cp, dp, fp);
    ip++;
    cp++;
    dp++;
    fp++;
    printf("%p %p %p %p", ip, cp, dp, fp);
}

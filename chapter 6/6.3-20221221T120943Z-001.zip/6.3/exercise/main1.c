#include<stdio.h>

void main()
{
    char str[50], *p;
    p=str;
    gets(str);

    while(*p)
    {
        if(*p==' ')
        {
            break;
        }
        p++;
    }
    p++;
    for(;*p;)
    printf("%c", *p++);
}

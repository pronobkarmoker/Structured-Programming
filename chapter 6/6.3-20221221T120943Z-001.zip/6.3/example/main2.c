#include<stdio.h>
#include<ctype.h>

void main()
{
    char str[80], *p;
    int i;

    printf("Enter a string: ");
    gets(str);
    p= str;

    while(*p)
    {
        *p++ = toupper(*p);
    }
    p=str;
    printf("%s\n", p);

    while(*p)
    {
        *p++ = tolower(*p);
    }
    p=str;
    printf("%s", p);
}

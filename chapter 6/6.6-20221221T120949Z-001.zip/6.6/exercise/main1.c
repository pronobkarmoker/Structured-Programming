#include<stdio.h>

void main()
{
    int i=6, *x, **mp;

    x= &i;
    mp=&x;
    **mp=10;
    printf("%p %p %p", x,mp, &i);
}

#include<stdio.h>

int main()
{
    char *p, **mp, str[80];
    
    p=str;
    mp= &p;
    
    printf("Enter string: ");
    gets(*mp);
    printf("Hi %s", *mp);
    return 0;
}
#include<stdio.h>

void mystrcpy(char *p, char *q)
{
    while(*q)
        *p++= *q++;
    *p='\0';
}
void main()
{
    char str[50];
    mystrcpy(str, "This is a test");
    printf(str);
}

#include<stdio.h>

int func(int *p)
{
    *p= -1;
}
void main()
{
    int n;
    func(&n);
    printf("%d", n);
}

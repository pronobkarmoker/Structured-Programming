#include<stdio.h>

void main()
{
    char str[80],*p;
    p=str;
    int space=0;

    printf("Enter string: ");
    gets(str);

    while(*p)
    {
        if(*p==' ')
            space++;
        p++;
    }
    printf("Number of spaces: %d", space);
}

#include<stdio.h>

void main()
{
    int n, *p;
    p=&n;
    *p=10;
    printf("%d", n);
}

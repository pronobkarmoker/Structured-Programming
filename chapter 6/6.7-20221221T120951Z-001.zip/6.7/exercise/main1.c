#include<stdio.h>

void mystrcat(char *p, char *q)
{
    while(*p)
        p++;
    while(*q)
        *p++ = *q++;
    *p= '\0';
}
void main()
{
    char str1[100], str2[50];
    gets(str1);
    gets(str2);
    mystrcat(str1, str2);
    printf(str1);

}

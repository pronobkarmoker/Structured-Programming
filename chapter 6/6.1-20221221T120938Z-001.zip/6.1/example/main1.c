#include<stdio.h>

void main()
{
    int *p;
    double q, temp;
    temp = 1234.34;

    p=&temp;
    q= *p;
    printf("%d", q);
}

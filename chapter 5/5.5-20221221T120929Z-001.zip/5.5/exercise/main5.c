#include<stdio.h>
#include<string.h>

void main()
{
    char str[50];
    int i,j;

    printf("Enter a string: ");
    gets(str);
    j= strlen(str)-1;
    for(i=0; i<=j; i++)
    {
        if(i<j)
            printf("%c%c", str[i], str[j]);
        else
            printf("%c", str[i]);
        j--;
    }
}

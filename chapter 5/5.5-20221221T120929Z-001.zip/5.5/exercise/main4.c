#include<stdio.h>
#include<string.h>

void main()
{
    char str[80];
    int i;

    printf("Enter a string: ");
    gets(str);

    for(i=strlen(str); i<79; i++)
    {
        strcat(str, ".");
    }
    printf(str);
}

#include<stdio.h>
#include<string.h>

void main()
{
    char str[80];
    int i, period=0,space=0,comma=0;

    printf("Enter a string: ");
    gets(str);

    for(i=0; str[i]; i++)
    {
        switch(str[i]){
        case ' ':
            space++;
            break;
        case '.':
            period++;
            break;
        case ',':
            comma++;
            break;
        }
    }
    printf("Spaces: %d\ncommas: %d\nperiods: %d", space, comma, period);
}

#include<stdio.h>
#include<string.h>

void main()
{
    char word[]= "concatenation";
    char str[]= "-------------";
    char ch;
    int i, count=0;
    do
    {
    printf("%s", str);
    printf("\nEnter guesses: ");
    ch = getchar();
    printf("\n");
    for(i=0; i<strlen(word); i++)
        if(ch == word[i]) str[i]= ch;
        count++;
    }while(strcmp(str, word));
    printf("%s\n", str);
    printf("You guessed it and guesses: %d", count);
}

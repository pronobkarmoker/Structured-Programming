#include<stdio.h>
#include<string.h>
void main()
{
    char word[][2][50]= {
         "hello", "greetings",
         "yes", "affirmative",
         "condition", "state",
         "affectionate", "loving",
         "always", "everytime",
         "", ""
    }, english[50];
    int i=0;

    printf("Enter word: ");
    gets(english);

    while(strcmp(word[i][0], ""))
    {
        if(!(strcmp(english, word[i][0])))
        {
            printf("Meaning: %s", word[i][1]);
            break;
        }
        i++;
    }
    if(!strcmp(word[i][0], ""))
    {
        printf("Not in dictionary");
    }
}

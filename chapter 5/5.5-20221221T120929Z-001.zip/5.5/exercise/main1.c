#include<stdio.h>
#include<conio.h>

void main()
{
    char text[10][10]= {
         "zero", "one", "two",
         "three", "four", "five",
         "six", "seven", "eight",
         "nine"
    };
    char num;

    printf("Enter number: ");
    num = getche();

    num -= '0';
    printf("\n%s", text[num]);
}

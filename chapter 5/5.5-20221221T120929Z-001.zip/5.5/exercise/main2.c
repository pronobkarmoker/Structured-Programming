#include<stdio.h>

void main()
{
    int num[20],i,j,oldmode=0,mode,count,max=0;
     printf("Enter numbers: ");

     for(i=0; i<20; i++)
     {
         scanf("%d", &num[i]);
     }

     for(i=0; i<20; i++)
     {
         mode = num[i];
         count=1;
         for(j=i+1; j<20; j++)
         {
             if(num[i]== num[j])
                count++;
         }
         if(count>max){
            max = count;
            oldmode = mode;
         }
     }
     printf("Mode is %d", oldmode);
}

#include<stdio.h>
#include<string.h>
void main()
{
    char str[50];
    int i;

    do
    {
        printf("Enter a string: ");
        gets(str);
    }
    while(strcmp(str, "quit"));
}

#include<stdio.h>

void main()
{
    char name[10][80];
    int i;

    for(i=0; i<10; i++)
    {
        printf("%d", i+1);
        gets(name[i]);
    }
    do
    {
        printf("Enter number of string(1-10): ");
        scanf("%d", &i);
        if(i>0 && i<=10)
        {
            printf("%s\n", name[i-1]);
        }
    }
    while(i>=0);
}

#include<stdio.h>
#include<string.h>

void main()
{
    char name[50];

    printf("Enter string: ");
    gets(name);

    for(int i=strlen(name)-1; i>=0; i--)
        printf("%c", name[i]);
}

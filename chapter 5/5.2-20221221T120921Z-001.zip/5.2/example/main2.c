#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void main()
{
    char command[80], temp[80];
    int i, j;

    for(;;)
    {
        printf("Operation? ");
        gets(command);

        if(!(strcmp(command, "quit")))
            break;
        printf("Enter number: \n");
        gets(temp);
        i = atoi(temp);

        printf("Enter 2nd number: \n");
        gets(temp);
        j = atoi(temp);

        if(!(strcmp(command, "add")))
            printf("Sum: %d\n", i+j);
        else if(!(strcmp(command, "substract")))
            printf("Ans: %d\n", i-j);
        else if(!(strcmp(command, "multiply")))
            printf("Ans: %d\n", i*j);
        else if(!(strcmp(command, "divide")) && j)
            printf("Ans: %d\n", i/j);
        else
            printf("Unknown command\n");
    }
}

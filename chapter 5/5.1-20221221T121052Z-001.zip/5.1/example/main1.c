#include<stdio.h>

void main()
{
    int temp[50],i,min=100,max=0,avg=0,days,sum=0;

    printf("How many days? ");
    scanf("%d", &days);

    for(i=0; i<days; i++)
    {
        printf("Enter temps: ");
        scanf("%d", &temp[i]);
    }

    for(i=0; i<days; i++)
    {
        sum+=temp[i];
    }
    printf("Avg: %d\n", sum/days);

    for(i=0; i<days; i++)
    {
        if(temp[i]>max)
            max = temp[i];
        if(temp[i]<min)
            min = temp[i];
    }
    printf("Minimum temp: %d\n", min);
    printf("Maximum temp: %d", max);
}

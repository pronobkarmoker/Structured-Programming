#include<stdio.h>
#include<conio.h>

void main()
{
    char mess[50];
    int i;
    for(i=0; i<50; i++)
    {
        mess[i]= getche();
        if(mess[i]=='\r')
            break;
    }
    for(i=0; mess[i]!='\r'; i++)
        printf("%c", mess[i]+1);
}

#include<stdio.h>

void main()
{
    int num[10],i,j, count=0;

    for(i=0; i<10; i++)
    {
        scanf("%d", &num[i]);
    }

    for(i=0; i<10; i++)
    {
        for(j=i+1; j<10; j++)
        {
            if(num[i] == num[j])
            {
                printf("%d is duplicated\n", num[i]);
            }
        }
    }
}

#include<stdio.h>

void main()
{
    int num,i,j,b;
    float temp;

    printf("Enter number of elements: ");
    scanf("%d", &num);

    float nums[num];

    for(i=0; i<num; i++)
    {
        scanf("%f", &nums[i]);
    }

    for(i=1; i<num; i++)
    {
        for(b=num-1; b>=i; --b)
        {
            if(nums[b-1]>nums[b])
            {
                temp = nums[b-1];
                nums[b-1] = nums[b];
                nums[b] = temp;
            }
        }
    }
    for(i=0; i<num; i++)
        printf("%.2f\n", nums[i]);
}

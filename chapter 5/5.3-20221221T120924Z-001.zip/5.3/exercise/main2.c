#include<stdio.h>

void main()
{
    int num[3][3][3], n=1, sum=0;

    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            for(int k=0; k<3; k++)
            {
                num[i][j][k]= n;
                n++;
                sum += num[i][j][k];
            }
        }
    }
    printf("%d", sum);
}

#include<stdio.h>

void main()
{
     int num[3][3][3],i,j,k,x=1;

     for(i=0; i<3; i++)
     {
        for(j=0; j<3; j++)
        {
            for(k=0; k<3; k++)
            {
                num[i][j][k] = x;
                x++;
                printf("%d\n", num[i][j][k]);
            }
        }
     }
}

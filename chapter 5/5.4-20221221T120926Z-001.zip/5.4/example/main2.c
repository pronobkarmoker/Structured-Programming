#include<stdio.h>
#include<string.h>

void main()
{
    char str[80]= "I like C";

    strcpy(str, "Hello");
    printf(str);
}

#include<stdio.h>

void main()
{
    int serverUsers[5][2]={
       1,14,
       2,28,
       3,19,
       4,8,
       5,15
    };
    int server,i;
    printf("Enter server number: ");
    scanf("%d", &server);

    for(i=0; i<5; i++)
    {
        if(server == serverUsers[i][0])
        {
            printf("There are %d users in server %d", serverUsers[i][1], server);
            break;
        }
    }
    if(i==5)
        printf("Server not found.");
}
